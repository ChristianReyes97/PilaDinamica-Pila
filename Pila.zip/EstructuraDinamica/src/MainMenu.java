
public class MainMenu {

	public static void main(String[] args) {

		PilaDinamica<Integer> pilaNumeros = new PilaDinamica<>();

		pilaNumeros.push(5);
		pilaNumeros.push(10);
		pilaNumeros.push(15);
		pilaNumeros.push(20);

		System.out.println("El tama�o de la pila es de: " + pilaNumeros.size());
		System.out.println("--------------------------------------------------");
		System.out.println("El top es: " + pilaNumeros.top());
		System.out.println("--------------------------------------------------");

		int elemento = pilaNumeros.pop();
		System.out.println("Se ha eliminado el numero: " + elemento);
		System.out.println("--------------------------------------------------");

		System.out.println("El tama�o de la pila es de: " + pilaNumeros.size() + " elementos");
		System.out.println("Los elementos que quedan en la pila dinamica son: \n" + pilaNumeros);
	}

}
