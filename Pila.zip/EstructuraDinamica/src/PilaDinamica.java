
public class PilaDinamica<T> {

	private Nodo<T> top;
	private int tamano;

	public PilaDinamica() {
		top = null;
		this.tamano = 0;

	}

	public boolean isEmpty() {
		return top == null;

	}

	public int size() {
		return this.tamano;

	}

	// DEVUELVE EL ELEMENTO QUE ESTA ARRIBA
	public T top() {
		if (isEmpty()) {
			return null;
		} else {
			return top.getElemento();
		}

	}

	// SACA EL ELEMENTO Y LO ELIMINA
	public T pop() {
		if (isEmpty()) {
			return null;
		} else {
			T elemento = top.getElemento();
			Nodo<T> aux = top.getSiguiente();
			top = null;
			top = aux;
			this.tamano--;
			return elemento;
		}
	}

	public void push(T elemento) {

		Nodo<T> aux = new Nodo<>(elemento, top);
		top = aux;
		this.tamano++;

	}

	public String toString() {

		if (isEmpty()) {
			return "La pila esta vacia";
		} else {

			String resultado = " ";
			Nodo<T> aux = top;
			while (aux != null) {
				resultado += aux.toString();
				aux = aux.getSiguiente();
			}
			return resultado;
		}

	}
}